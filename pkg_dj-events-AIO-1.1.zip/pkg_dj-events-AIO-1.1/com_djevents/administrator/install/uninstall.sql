DROP TABLE IF EXISTS `#__djev_cats`;
DROP TABLE IF EXISTS `#__djev_cities`;
DROP TABLE IF EXISTS `#__djev_events`;
DROP TABLE IF EXISTS `#__djev_events_media`;
DROP TABLE IF EXISTS `#__djev_events_time`;
DROP TABLE IF EXISTS `#__djev_tags`;
DROP TABLE IF EXISTS `#__djev_tags_xref`;
<?php
/**
 * @package DJ-Events
 * @copyright Copyright (C) DJ-Extensions.com, All rights reserved.
 * @license http://www.gnu.org/licenses GNU/GPL
 * @author url: http://dj-extensions.com
 * @author email contact@dj-extensions.com
 * @developer Szymon Woronowski - szymon.woronowski@design-joomla.eu
 *
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
?>

<div class="djev_calendar_days" data-baseurl="<?php echo JUri::base(); ?>" data-module="<?php echo $params->get('module', 0) ?>">
    <?php
    $date = JFactory::getDate($params->get('start_date', 'now'));
    $today = JFactory::getDate()->format('Y-m-d');
    $start = $date->format('Y-m-d');
    $end = JFactory::getDate($start . ' +12 month')->format('Y-m-d');
    $days = $params->get('days', 3);
    ?>

    <div class="djev_calendar_scroll">
        <div class="djev_calendar_scroll_in">
            <?php
//            $i = 0;
            foreach ($items as $itemSub) {
                $conteudo = "";
                $current = JFactory::getDate($itemSub[0]->start);
//                $current = JFactory::getDate($itemSub[0]->start)->format('Y-m-d');
//                $current = new DateTime($current);
//                if($current == $end){
//                    exit;
//                }
                $link = JRoute::_(DJEventsHelperRoute::getEventsListRoute() . '&from=' . $current->format('Y-m-d') . '&to=' . $current->format('Y-m-d'));
                $i = 1;
                foreach ($itemSub as $item) {
                    $conteudo .= '<div class=&quot;djev_calendar_event&quot;>
 			<span class=&quot;time&quot;>
 			 			</span>
			<a class=&quot;title&quot; href=&quot;' . $item->link . '&quot;>' . $item->title . '</a>
		</div>';
                    if ($i == 3) {
                        break;
                    }
                    $i++;
                }
                $conteudo .= '<div class=&quot;djev_calendar_event center djev_calendar_day_link&quot;>
	<a href=&quot;' . $link . '&quot;>
		Eventos do Dia</a>
	</div>';
                ?>
                <a href="<?php echo $link ?>" class="djev_calendar_day active-day" 
                   data-content=" <?= $conteudo ?>" data-date="<?php echo $current; ?>">
                    <span class="djev_calendar_day_in">
                        <span class="week_day">
                            <?php echo JHtml::_('date', $current->format('Y-m-d') . '+1 days', 'l'); ?>
                        </span>
                        <span class="day">
                            <?php echo JHtml::_('date', $current->format('Y-m-d') . '+1 days', 'd'); ?>
                        </span>
                        <span class="month">
                            <?php echo JHtml::_('date', $current->format('Y-m-d') . '+1 days', 'M'); ?>
                        </span>
                    </span>
                </a>
                <?php
//                $i++;
            }
            ?>
        </div>
    </div>

    <a class="prev-days" href="#"><i class="fa fa-angle-left"></i></a>
    <a class="next-days" href="#"><i class="fa fa-angle-right"></i></a>	

    <div class="djev_loader"><span class="fa fa-refresh fa-spin fa-3x"></span></div>

    <?php if ($params->get('show_link')) { ?>
        <div class="djev_calendar_more">
            <a href="<?php echo JRoute::_(DJEventsHelperRoute::getEventsListRoute()) ?>"><?php echo JText::_('MOD_DJEVENTS_CALENDAR_SHOW_ALL') ?></a>
        </div>
    <?php } ?>

    <div style="clear:both"></div>
</div>
<?php 